
const DICT = {"he": {"nav_services": "שירותים", "nav_pricing": "תמחור", "nav_faq": "שאלות", "nav_contact": "צור קשר", "hero_title": "הובלות ללא דאגות — אמינות, דייקנות וחיוך", "hero_sub": "דירות · משרדים · אריזה · פירוק והרכבה · ציוד כבד", "cta_quote": "קבלו הצעת מחיר", "cta_services": "לשירותים", "cta_email": "או כתבו לנו מייל", "quote_title": "הצעת מחיר מהירה", "f_name": "שם", "f_phone": "טלפון", "f_route": "מוצא → יעד", "f_date": "תאריך", "f_notes": "פרטים", "f_send": "שלח ל‑WhatsApp", "f_hint": "אפשר לצרף תמונות אחרי השליחה", "services_title": "שירותים", "s1_h": "הובלות דירות", "s1_p": "שמיכות ורצועות, הגנה מלאה לרהיטים.", "s2_h": "משרדים", "s2_p": "פירוק והרכבה, סימון קרטונים, מינימום השבתה.", "s3_h": "הובלות כבדות", "s3_p": "מקררים, כספות, פסנתרים — עם רצועות כתפיים.", "s4_h": "אריזה", "s4_p": "קרטונים, עיטוף וניילון בועות — מסודר ובטוח.", "pricing_title": "תמחור", "pricing_sub": "החל מ‑₪349 להובלה מקומית (ת״א וגוש דן). המחיר הסופי לפי מרחק ונפח.", "reviews_title": "המלצות", "faq_title": "שאלות נפוצות", "fq1_q": "איך נקבע המחיר?", "fq1_a": "לפי מרחק, נפח ותנאים (קומות, מעלית, פירוק/הרכבה). נותנים מחיר סופי מראש.", "fq2_q": "יש ביטוח מטען?", "fq2_a": "כן. אורזים ומבטחים את המטען — שקט נפשי מובטח.", "fq3_q": "עובדים בסופי שבוע?", "fq3_a": "א׳–ה׳ 08:00–20:00, ו׳ 08:00–14:00. שעות אחרות — בתיאום.", "contact_title": "צור קשר", "c_phone_l": "טלפון:", "c_hours_l": "שעות פעילות:", "c_site_l": "אתר:"}, "ru": {"nav_services": "Услуги", "nav_pricing": "Цены", "nav_faq": "Вопросы", "nav_contact": "Контакты", "hero_title": "Переезды без хлопот — надёжно и вовремя", "hero_sub": "Квартиры · Офисы · Упаковка · Разборка/сборка · Тяжёлые грузы", "cta_quote": "Получить цену", "cta_services": "К услугам", "cta_email": "или напишите нам на e‑mail", "quote_title": "Быстрый расчёт", "f_name": "Имя", "f_phone": "Телефон", "f_route": "Откуда → Куда", "f_date": "Дата", "f_notes": "Детали", "f_send": "Отправить в WhatsApp", "f_hint": "Фото можно приложить после отправки", "services_title": "Услуги", "s1_h": "Квартирные переезды", "s1_p": "Одеяла, ремни, полная защита мебели.", "s2_h": "Офисы", "s2_p": "Разборка/сборка, маркировка коробок, минимум простоя.", "s3_h": "Тяжёлые", "s3_p": "Холодильники, сейфы, пианино — с плечевыми ремнями.", "s4_h": "Упаковка", "s4_p": "Коробки, плёнка, пузырчатая защита — аккуратно и безопасно.", "pricing_title": "Цены", "pricing_sub": "От ₪349 за местный переезд (Тель‑Авив и Гуш‑Дан). Итоговая цена зависит от расстояния и объёма.", "reviews_title": "Отзывы клиентов", "faq_title": "Частые вопросы", "fq1_q": "Как формируется цена?", "fq1_a": "Зависит от расстояния, объёма и условий (этажи, лифт, разборка/сборка).", "fq2_q": "Есть ли страховка груза?", "fq2_a": "Да, аккуратно упаковываем и страхуем груз.", "fq3_q": "Работаете по выходным?", "fq3_a": "Пн–Чт 08:00–20:00, Пт 08:00–14:00. Остальное — по согласованию.", "contact_title": "Контакты", "c_phone_l": "Телефон:", "c_hours_l": "Часы работы:", "c_site_l": "Сайт:"}, "en": {"nav_services": "Services", "nav_pricing": "Pricing", "nav_faq": "FAQ", "nav_contact": "Contact", "hero_title": "Moving without worries — reliable and on time", "hero_sub": "Homes · Offices · Packing · Assembly · Heavy items", "cta_quote": "Get a quote", "cta_services": "See services", "cta_email": "or send us an email", "quote_title": "Quick quote", "f_name": "Name", "f_phone": "Phone", "f_route": "From → To", "f_date": "Date", "f_notes": "Details", "f_send": "Send to WhatsApp", "f_hint": "You can attach photos after sending", "services_title": "Services", "s1_h": "Home moves", "s1_p": "Blankets, straps, full furniture protection.", "s2_h": "Offices", "s2_p": "Disassembly/assembly, labeled boxes, minimal downtime.", "s3_h": "Heavy items", "s3_p": "Fridges, safes, pianos — with shoulder straps.", "s4_h": "Packing", "s4_p": "Boxes, wrap, bubble — neat and safe.", "pricing_title": "Pricing", "pricing_sub": "From ₪349 for local moves (Tel‑Aviv & Gush Dan). Final price depends on distance and volume.", "reviews_title": "Customer reviews", "faq_title": "FAQ", "fq1_q": "How do you price?", "fq1_a": "By distance, volume, and conditions (floors, elevator, disassembly/assembly).", "fq2_q": "Is cargo insured?", "fq2_a": "Yes. We pack carefully and insure the load.", "fq3_q": "Weekend work?", "fq3_a": "Sun–Thu 08:00–20:00, Fri 08:00–14:00. Others by arrangement.", "contact_title": "Contact", "c_phone_l": "Phone:", "c_hours_l": "Hours:", "c_site_l": "Site:"}};
const waNumber = "972547524092";
const HOURS = {"he": "א'-ה' 08:00–20:00, ו' 08:00–14:00", "ru": "Пн–Чт 08:00–20:00, Пт 08:00–14:00", "en": "Sun–Thu 08:00–20:00, Fri 08:00–14:00"};

const $ = (s)=>document.querySelector(s);
const $$ = (s)=>Array.from(document.querySelectorAll(s));

function setLang(l){
  if(l === 'he'){ document.documentElement.setAttribute('dir','rtl'); document.documentElement.setAttribute('lang','he'); }
  else { document.documentElement.setAttribute('dir','ltr'); document.documentElement.setAttribute('lang', l); }
  const dict = DICT[l];
  $$('[data-i18n]').forEach(n=>{ const k=n.getAttribute('data-i18n'); if(dict[k]) n.textContent=dict[k]; });
  const hoursEl = document.getElementById('hours'); if(hoursEl) hoursEl.textContent = HOURS[l];
  $$('.lang-switch button').forEach(b=>b.classList.remove('active'));
  const btn = document.querySelector(`.lang-switch button[data-lang="${l}"]`); if(btn) btn.classList.add('active');
}

function waLinkFromForm(form){
  const data = new FormData(form);
  const name = (data.get('name')||'').trim();
  const phone = (data.get('phone')||'').trim();
  const route = (data.get('route')||'').trim();
  const date = (data.get('date')||'').trim();
  const notes = (data.get('notes')||'').trim();
  const msg = `Move4U — בקשת הצעת מחיר:%0Aשם/Name: ${encodeURIComponent(name)}%0Aטלפון/Phone: ${encodeURIComponent(phone)}%0Aמסלול/Route: ${encodeURIComponent(route)}%0Aתאריך/Date: ${encodeURIComponent(date)}%0Aפרטים/Notes: ${encodeURIComponent(notes)}`;
  return `https://wa.me/${waNumber}?text=${msg}`;
}

function init(){
  const y=document.getElementById('year'); if(y) y.textContent=new Date().getFullYear();
  $$('.lang-switch button').forEach(b=>b.addEventListener('click',()=>setLang(b.dataset.lang)));
  setLang('he');

  const genericWa = `https://wa.me/${waNumber}?text=${encodeURIComponent('שלום, רוצה הצעת מחיר להובלה')}`;
  ['waTop','waHero','waPricing','waContact'].forEach(id=>{ const a=$('#'+id); if(a) a.href=genericWa; });

  const form=document.getElementById('qform');
  if(form){
    form.addEventListener('submit',(e)=>{ e.preventDefault(); window.open(waLinkFromForm(form),'_blank'); });
  }
}
document.addEventListener('DOMContentLoaded', init);
